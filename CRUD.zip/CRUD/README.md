Clone về rồi thì vô file application.properties sửa ${DB_USERNAME}, ${DB_PASSWORD} thành username, password của MySQL của mình
