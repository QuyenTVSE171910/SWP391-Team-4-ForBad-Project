package com.swp391.teamfour.forbadsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForbadSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ForbadSystemApplication.class, args);
    }

}
