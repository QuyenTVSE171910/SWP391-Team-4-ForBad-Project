package com.swp391.teamfour.forbadsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForbadSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
